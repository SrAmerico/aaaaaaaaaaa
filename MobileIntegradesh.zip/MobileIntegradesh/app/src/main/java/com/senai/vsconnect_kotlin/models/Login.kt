package com.senai.vsconnect_kotlin.models

class Login(
    val email: String,
    val senha: String
)