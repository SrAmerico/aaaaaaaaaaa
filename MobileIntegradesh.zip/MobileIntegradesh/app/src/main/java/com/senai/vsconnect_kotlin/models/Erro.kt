package com.senai.vsconnect_kotlin.models

class Erro(
    val nomeerro : String
) {
}